from django.http import HttpResponse
from django.shortcuts import render
from datetime import datetime
from .models import Submission

# Create your views here.

def index(request):
    current_time = datetime.now()
    context = {'current_time' : current_time}
    return render(request, 'myapp/index.html',context)

def submit(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        submission = Submission(name=name, email=email)
        submission.save()
        return HttpResponse(f'Thank you {name}, your email is {email}.')
    else:
        return HttpResponse('Invalid request.')
    
def submissions(request):
    all_submissions = Submission.objects.all()
    context = {'submissions': all_submissions}
    return render(request, 'myapp/submissions.html', context)

